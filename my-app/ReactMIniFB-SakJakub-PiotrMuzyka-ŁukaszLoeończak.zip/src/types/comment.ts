export type Comment = {
    id: string
    authorId: string
    authorUsername: string
    postId: string
    body: string
}